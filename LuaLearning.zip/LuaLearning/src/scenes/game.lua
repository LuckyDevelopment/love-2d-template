local Scene = {}
Scene.__index = Scene

-- Returns this scene.
function Scene.new()
    local self = setmetatable({}, Scene)
    
    self.Name = "Game"
    self.CurrentTime = 0

    return self
end

-- Called when scene is loaded.
function Scene:load()
end

-- Called every frame to update things.
function Scene:update(dt)
    -- Example logic: after 5 seconds, switch to Menu scene
    self.CurrentTime = self.CurrentTime + dt

    if self.CurrentTime >= 5 then
        -- After 5 seconds, switch to Menu scene
        local SceneHandler = require("src.core.scene_handler")
        local MenuScene = require("src.scenes.menu")
        SceneHandler.set(MenuScene.new())
    end
end

-- Called every frame to draw things.
function Scene:draw()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Welcome to the Game Scene!", 350, 400)
end

-- Called when the scene is unloaded.     
function Scene:unload()
end

-- Called when a key is pressed.
function Scene:keypressed(key) end

return Scene
