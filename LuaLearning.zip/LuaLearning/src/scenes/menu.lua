local Scene = {}
Scene.__index = Scene

-- Returns this scene.
function Scene.new()
    local self = setmetatable({}, Scene)

    self.Name = "Menu"
    
    return self
end

-- Called when scene is loaded.
function Scene:load()
end

-- Called every frame to update things.
function Scene:update(dt)
end

-- Called every frame to draw things.
function Scene:draw()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Welcome to the Menu Scene!", 350, 450)
end

-- Called when the scene is unloaded.     
function Scene:unload()
end

-- Called when a key is pressed.
function Scene:keypressed(key) end

return Scene
