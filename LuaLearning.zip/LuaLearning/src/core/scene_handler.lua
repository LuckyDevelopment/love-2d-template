local SceneHandler = {}

SceneHandler.current_scene = nil

-- Sets the current scene.
function SceneHandler.set(scene)
    if SceneHandler.current_scene and SceneHandler.current_scene.unload then
        print("Unloaded \""..scene.Name.."\" scene.")
        SceneHandler.current_scene:unload()
    end

    if scene then
        SceneHandler.current_scene = scene
        SceneHandler.current_scene:load()

        print("Loaded \""..scene.Name.."\" scene.")
    else
        print("No scene to set!")
    end
end

-- Built in function to update the current scene.
function SceneHandler.update(dt)
    if SceneHandler.current_scene then
        SceneHandler.current_scene:update(dt)
    end
end

-- Built in function to draw the current scene.
function SceneHandler.draw()
    if SceneHandler.current_scene then
        SceneHandler.current_scene:draw()
    end
end

function SceneHandler.keypressed(key)
    if SceneHandler.current_scene and SceneHandler.current_scene.keypressed then
        SceneHandler.current_scene:keypressed(key)
    end
end

return SceneHandler