local AssetLoader = {}
AssetLoader.images = {}
AssetLoader.sounds = {}
AssetLoader.fonts = {}

-- Loads all assets.
function AssetLoader.load()
    --AssetLoader.images.player = love.graphics.newImage("assets/images/player.png")
end

return AssetLoader
