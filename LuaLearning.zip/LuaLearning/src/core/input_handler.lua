local Input = {}

Input.keys_down = {}
Input.keys_pressed = {}
Input.keys_released = {}

-- Called when a key is pressed
function Input.keypressed(key)
    if not Input.keys_down[key] then
        Input.keys_pressed[key] = true
    end
    Input.keys_down[key] = true
end

-- Called when a key is released
function Input.keyreleased(key)
    Input.keys_down[key] = false
    Input.keys_released[key] = true
end

-- Query functions
function Input.isDown(key)
    return Input.keys_down[key] == true
end

function Input.wasPressed(key)
    return Input.keys_pressed[key] == true
end

function Input.wasReleased(key)
    return Input.keys_released[key] == true
end

-- Called each frame to clear one-time events
function Input.update()
    for k in pairs(Input.keys_pressed) do
        Input.keys_pressed[k] = nil
    end
    for k in pairs(Input.keys_released) do
        Input.keys_released[k] = nil
    end
end

return Input
