_G.love = require("love")

local SceneHandler = require("src.core.scene_handler")
local GameScene = require("src.scenes.game")
local Input = require("src.core.input_handler")
local AssetManager = require("src.core.asset_manager")

function love.load()
    AssetManager.load()
    SceneHandler.set(GameScene.new())
end

function love.update(dt)
    SceneHandler.update(dt)
    Input.update()
end

function love.draw()
    SceneHandler.draw()
end

function love.keypressed(key)
    Input.keypressed(key)
    SceneHandler.keypressed(key)
end

function love.keyreleased(key)
    Input.keyreleased(key)
end