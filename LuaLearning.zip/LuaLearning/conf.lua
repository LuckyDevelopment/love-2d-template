function love.conf(t)
    t.window.title = "Dev V.1.0"

    t.window.resizable = false
    t.window.height = 800
    t.window.width = 800
end